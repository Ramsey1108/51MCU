#ifndef __KEYSCAN_H
#define	__KEYSCAN_H

unsigned char number(void);

#endif