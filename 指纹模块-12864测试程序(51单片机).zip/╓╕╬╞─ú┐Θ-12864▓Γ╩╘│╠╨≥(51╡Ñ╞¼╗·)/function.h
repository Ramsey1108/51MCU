#ifndef __FUNCTION_H
#define	__FUNCTION_H

void Menu(void);
void Enter_Ppassword(void); 		
void Enter_Fingerprint(void); 	
void Change_Password(void); 		
void Change_Fingerprint(void); 

#endif
