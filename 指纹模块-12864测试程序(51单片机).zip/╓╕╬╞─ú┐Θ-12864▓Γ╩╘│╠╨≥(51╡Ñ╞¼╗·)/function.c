#include <reg52.h>
#include "function.h"
#include "lcd_12864.h"
#include "KeyScan.h"

sbit Beep = P2^4;
sbit LED = P3^4;

unsigned char Default_Password[] = {"159357"};

extern void Delay_Ms(unsigned int z);

/* �˵����� */
void Menu(void)
{
		LCD_PutString(0, 1," A  ���뿪��");
		LCD_PutString(0, 2," B  ָ�ƿ���");
		LCD_PutString(0, 3," C  �޸�����");
		LCD_PutString(0, 4," D  �޸�ָ��");
}

/* ��ȡ��λ���� */
void Getting_Password(unsigned char *p)
{
		unsigned char Key;
		unsigned char i = 0;
		while(i != 6)
		{
				Key = number();
				if(Key)
				{
						p[i++] = Key;
						LCD_Display("*");
				}
				Delay_Ms(50);
		}
}	

/* �������� */
unsigned char Enter_Password(void)
{
		unsigned char i, num = 0;
		unsigned char password[7];
		ClrScreen();
		LCD_PutString(0, 1," INPUT PASSWORD");
	
		for(num = 0; num < 3; num++)
		{
				LCD_PutString(2, 2,"        ");
				LCD_PutString(2, 4,"        ");
				LCD_Address(1,2);
				Getting_Password(password);
			
				for(i = 0; i < 6; i++)
						if(password[i] != Default_Password[i])
								break;
				if(i < 6)
				{
						LCD_PutString(2, 4,"ERROR");
						i = 0;
						Beep = 0;
						LED = 0;
				}
				else 
				{
						LCD_PutString(2, 4," OPEN");
						i = 1;
						break;
				}
				Delay_Ms(1500);
				Beep = 1;
				LED = 1;
		}
		if(num==3 && i==0)
		{
				LCD_PutString(2, 4,"������");
		}
		Delay_Ms(2000);
		ClrScreen();
		return i;
}	

void Enter_Fingerprint(void)
{
		
} 	

void Change_Password(void)
{
		unsigned char i = 0;
		unsigned char password1[7], password2[7];
	
		if( Enter_Password() )
		{		
				LCD_PutString(1, 1,"NWE PASSWORD");
				LCD_Address(1,2);
				Getting_Password(password1);
				LCD_PutString(2, 3," AGAIN");
				LCD_Address(3,2);
				Getting_Password(password2);
				for(i = 0; i < 6; i++)
						if(password1[i] != password2[i])
								break;
				if(i < 6)
						LCD_PutString(2, 4,"ERROR");
				else 
						LCD_PutString(2, 4,"SUCCEED");
				Delay_Ms(2500);
				ClrScreen();
		}
}

void Change_Fingerprint(void)
{
	
}

