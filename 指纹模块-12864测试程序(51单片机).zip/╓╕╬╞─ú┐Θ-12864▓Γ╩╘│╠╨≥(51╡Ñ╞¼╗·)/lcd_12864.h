#ifndef __LCD__
#define __LCD__

#define DataPort P0

extern char local_date,base_date;
extern unsigned char code *Main_Menu[];

sbit RS = P1^0;
sbit RW = P1^1;
sbit E  = P1^2;
sbit PSB   = P1^3;
sbit RES   = P1^4;

void DisplayUpdata(void);
void ClrScreen();
void LCD_PutString(unsigned char x,unsigned char y,unsigned char code *s);
void DisplayCGRAM(unsigned char x,unsigned char y);
void CGRAM();
void Init_ST7920();
void Write_Data(unsigned char Data);
void Write_Cmd(unsigned char Cmd);
void Check_Busy();

#endif
