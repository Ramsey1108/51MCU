#include <reg52.h>
#include "KeyScan.h"

//4*4��Ĥ����������P1��

extern void delay_ms(unsigned int z);

unsigned char Key_Scan()
{
	unsigned char cord_l,cord_h;
	P1 = 0xf0;//1111 0000
	if( (P1 & 0xf0) != 0xf0)
	{
		delay_ms(5);
		if( (P1 & 0xf0) != 0xf0)
		{
			  cord_l = P1 & 0xf0;
			  P1 = cord_l | 0x0f;
			  cord_h = P1 & 0x0f;
			  while( (P1 & 0x0f) != 0x0f );
			  return (cord_l + cord_h);
		}	
	}		
}

unsigned char number(void)
{
	  unsigned char Key,num='\0';				
		Key = Key_Scan();
		if(Key)
		{
			switch( Key )
			{
				case 0xee: num='1'; break;
				case 0xde: num='2';	break;
				case 0xbe: num='3';	break;		
				case 0xed: num='4';	break;
				case 0xdd: num='5';	break;
				case 0xbd: num='6';	break;		
				case 0xeb: num='7';	break;
				case 0xdb: num='8';	break;
				case 0xbb: num='9';	break;	
				case 0xd7: num='0';	break;
				case 0x7e: num='A';break;	
				case 0x7d: num='B';break;	
				case 0x7b: num='C';break;
				case 0x77: num='D';break;
				case 0xb7: num='#';break;
				case 0xe7: num='*';break;
				default : break;
			}			
			delay_ms(50);
		}	
	return num;
}

