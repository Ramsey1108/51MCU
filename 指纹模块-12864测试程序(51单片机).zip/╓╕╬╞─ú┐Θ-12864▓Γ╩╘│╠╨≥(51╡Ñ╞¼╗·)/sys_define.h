#ifndef __SYS_DEFINE_H
#define	__SYS_DEFINE_H

#define uchar unsigned char
#define uint unsigned int	

#define u8 unsigned char
#define u16 unsigned int		

#endif